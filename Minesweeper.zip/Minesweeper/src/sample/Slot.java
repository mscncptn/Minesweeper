package sample;

import javafx.application.Platform;
import javafx.geometry.Point2D;
import javafx.scene.Group;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Slot {

    int value;
    boolean active = false;
    Image BLOCK = new Image("/sample/Block.png", 40, 40, true, true);
    Image valuepic;  // Resourse for showing after pressing
   // ImageView imgVALUE; //Shows value after pressing
    ImageView imgMAIN ;  //Shows block
    int X;
    int Y;


    //Constructor that creates every slot
    public Slot(int value, int x, int y)
    {
        this.value = value;
        switch (value)
        {
            case 1:
                valuepic = new Image("/sample/1.png", 40, 40, true, true);
                break;
            case 2:
                valuepic = new Image("/sample/2.png", 40, 40, true, true);
                break;
            case 3:
                valuepic = new Image("/sample/3.png", 40, 40, true, true);
                break;
            case 4:
                valuepic = new Image("/sample/4.png", 40, 40, true, true);
                break;
            case 5:
                valuepic = new Image("/sample/5.png", 40, 40, true, true);
                break;
            case 6:
                valuepic =new Image("/sample/6.png", 40, 40, true, true);
                break;
            case 7:
                valuepic = new Image("/sample/7.png", 40, 40, true, true);
                break;
            case 9:
                valuepic = new Image("/sample/Mine.png", 40, 40, true, true);
                break;
            case 0:
                valuepic = new Image("/sample/Empty.png", 40, 40, true, true);
                break;
        }
        imgMAIN = new ImageView(BLOCK);
        X = x;
        Y = y;
    }

    public ImageView setImgMAIN(int x, int y) {
        imgMAIN.setX(x);
        imgMAIN.setY(y);
        return imgMAIN;
    }

    public void MouseClick(double x, double y)
    {
        Point2D point = new Point2D(x, y);
        if (imgMAIN.contains(point))
        {
            if (active == false)
            {
                if (value == 9)
                {
                    active = true;
                    imgMAIN.setImage(valuepic);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("You losed");
                    alert.setHeaderText("You losed");
                    alert.showAndWait();
                    Platform.exit();
                }
                else if (value == 0) {
                    OpenSlot();
                }
                else
                {
                    active = true;
                    imgMAIN.setImage(valuepic);
                }
            }
        }
    }

    private void OpenSlot()
    {
        if (!active) {
            active = true;
            if (imgMAIN.getImage() != valuepic)
                imgMAIN.setImage(valuepic);

            if (X + 1 < 20) {
                if (Field.MainField[X + 1][Y].value == 0) {
                    Field.MainField[X + 1][Y].OpenSlot();
                }
                else {
                    Field.MainField[X + 1][Y].active = true;
                    Field.MainField[X + 1][Y].imgMAIN.setImage(Field.MainField[X + 1][Y].valuepic);
                }
            }

            if (X - 1 >= 0) {
                if (Field.MainField[X - 1][Y].value == 0) {
                    Field.MainField[X - 1][Y].OpenSlot();
                }
                else {
                    Field.MainField[X - 1][Y].active = true;
                    Field.MainField[X - 1][Y].imgMAIN.setImage(Field.MainField[X - 1][Y].valuepic);
                }
            }

            if (Y - 1 >= 0) {
                if (Field.MainField[X][Y - 1].value == 0) {
                    Field.MainField[X][Y - 1].OpenSlot();
                }
                else {
                    Field.MainField[X][Y - 1].active = true;
                    Field.MainField[X][Y - 1].imgMAIN.setImage(Field.MainField[X][Y - 1].valuepic);
                }
            }

            if (Y + 1 < 20) {
                if (Field.MainField[X][Y + 1].value == 0) {
                    Field.MainField[X][Y + 1].OpenSlot();
                }
                else {
                    Field.MainField[X][Y + 1].active = true;
                    Field.MainField[X][Y + 1].imgMAIN.setImage(Field.MainField[X][Y + 1].valuepic);
                }
            }
        }

    }

    public void Flaging(double x, double y)
    {
        Point2D point = new Point2D(x, y);

        if (imgMAIN.contains(point) && imgMAIN.getImage() != valuepic)
        {
            if (!active) {
                active = true;
                BLOCK = new Image("/sample/BlockFlag.png", 40, 40, true, true);
                imgMAIN.setImage(BLOCK);
                Field.FlagCount -=1;
            }
            else
            {
                active = false;
                BLOCK = new Image("/sample/Block.png", 40, 40, true, true);
                imgMAIN.setImage(BLOCK);
                Field.FlagCount +=1;
            }
        }
    }



/*
    public ImageView getImgVALUE() {
        return imgVALUE;
    }
    */
}
