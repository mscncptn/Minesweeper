package sample;

import javafx.scene.control.Label;

import java.util.Random;

public class Field {


    public static int FlagCount = 40;
    int [][] FieldMath = new int [20][20];
   public static Slot[][] MainField = new Slot[20][20];

    public void MineFill()
    {
        for(int i = 0; i < 40; i++) {
            Random rnd = new Random();
            int x = rnd.nextInt(20);
            int y = rnd.nextInt(20);
            FieldMath[x][y] = 9;
        }
    }

    public void NumberFill()
    {
        for (int i = 0; i < 20; i++)
        {
            for ( int j = 0; j < 20; j++)
            {
                if (FieldMath[i][j] == 9)
                {
                    if (i - 1 >= 0)
                    {
                        if (FieldMath[i - 1][j] != 9 )
                        FieldMath[i - 1][j] += 1;
                    }
                    if (i - 1 >= 0 && j - 1>= 0)
                    {
                        if (FieldMath[i - 1][j - 1] != 9 )
                        FieldMath[i - 1][j -1 ] += 1;
                    }
                    if (j - 1>= 0)
                    {
                        if (FieldMath[i][j - 1] != 9 )
                        FieldMath[i][j - 1] += 1;
                    }
                    if (i + 1 < 20 && j - 1>= 0)
                    {
                        if (FieldMath[i + 1][j - 1] != 9 )
                            FieldMath[i +1][j - 1] += 1;
                    }
                    if (i + 1 < 20 )
                    {
                        if (FieldMath[i + 1][j] != 9 )
                            FieldMath[i + 1][j] += 1;
                    }
                    if (i + 1 < 20 && j + 1 < 20)
                    {
                        if (FieldMath[i + 1][j + 1] != 9 )
                            FieldMath[i + 1][j + 1] += 1;
                    }
                    if (j + 1< 20)//
                    {
                        if (FieldMath[i][j + 1] != 9 )
                            FieldMath[i][j + 1] += 1;
                    }
                    if (i - 1 >= 0 && j + 1< 20)//
                    {
                        if (FieldMath[i - 1][j + 1] != 9 )
                            FieldMath[i - 1][j + 1] += 1;
                    }
                }
            }
        }
    }

    public void FieldView()
    {
        for(int i = 0; i < 20; i++)
        {
            System.out.print("\n");
            for (int j = 0; j < 20; j++ )
            {
                System.out.print(FieldMath[i][j] + " ");
            }
        }
    }

    public void MainFieldGeneration()
    {
        for(int i = 0; i < 20; i++)
        {
            for(int j = 0; j < 20; j++)
            {
                MainField[i][j] = new Slot(FieldMath[i][j], i, j);
            }
        }
    }

}
