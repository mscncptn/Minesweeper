package sample;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {


    Group group;
    @Override
    public void start(Stage primaryStage) throws Exception{
        Field field = new Field();
        field.MineFill();
        field.NumberFill();
        field.FieldView();
        field.MainFieldGeneration();
        group = new Group();
        for(int i = 0; i <= 760; i+=40)
        {
            for(int j = 0; j <= 760; j+=40)
            {
                group.getChildren().add(Field.MainField[i/40][j/40].setImgMAIN(i,j));
            }
        }
        Scene scene = new Scene(group, 800, 800);
        scene.setFill(Color.GRAY);
        scene.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                MouseButton button = event.getButton();
                if (button == MouseButton.PRIMARY) {
                    for (int i = 0; i < 20; i++) {
                        for (int j = 0; j < 20; j++) {
                            Field.MainField[i][j].MouseClick(event.getX(), event.getY());
                        }
                    }
                }
                else if (button == MouseButton.SECONDARY)
                {
                    for (int i = 0; i < 20; i++) {
                        for (int j = 0; j < 20; j++) {
                            Field.MainField[i][j].Flaging(event.getX(), event.getY());
                        }
                    }
                }
            }
        });
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
